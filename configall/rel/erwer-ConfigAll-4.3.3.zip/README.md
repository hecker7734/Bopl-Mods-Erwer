I lied the mod isn't fully done LOL, but, here is what is in the mod:

## New Update:
# Tap Abilties
you can know tap bow and grenade to instantly charge them!


## Major Update!
All Abilties' cooldowns can now be changed in config!


# Duplicator Ray
- Amount of X Duplicated (3 Settings)
- Lifespan of duplicated objects
- player count for dupes
- keep abilities after duped
- remember duped platforms

# Beam
- Length
- Size

# Gust
- Radius
- Strength Multiplier



##  Changelog:  
  
10/12/24 - Fixed TapNade bug:  
Fixed a bug where grenades always instantly charged.  