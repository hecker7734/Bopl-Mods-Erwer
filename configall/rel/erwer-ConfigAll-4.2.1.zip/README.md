I lied the mod isn't fully done LOL, but, here is what is in the mod:

## Major Update!
All Abilties' cooldowns can now be changed in config!


# Duplicator Ray
- Amount of X Duplicated (3 Settings)
- Lifespan of duplicated objects
- player count for dupes
- keep abilities after duped
- remember duped platforms

# Beam
- Length
- Size

# Gust
- Radius
- Strength Multiplier

