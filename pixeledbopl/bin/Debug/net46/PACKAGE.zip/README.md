Pixelates the game using custom shaders.

## You can disable slime trail pixelation in config
## You can change the amount pixelation in config