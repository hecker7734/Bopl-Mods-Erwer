This mod doesn't do anything for you, on its own;
Its a library mod without a lot;
It will be updated;

# For any modders:
- **`try_kill_player` is deprecated, but will not be removed**
## AGoodNameLib Documentation

### Classes and Methods

#### `AGoodNameLib.player`

This class provides static methods to interact with player objects.


- **`do_kill_player(PlayerBody __body, int id = 256, CauseOfDeath cod = CauseOfDeath.Accident)`**
  - Attempts to kill the specified player, marking the death with a specified cause of death.
  - **Parameters:**
    - `__body`: The player's body that will be affected.
    - `id`: The ID of the killer (defaults to 256).
    - `cod`: The cause of death (defaults to `CauseOfDeath.Accident`).
  - **Returns:** `True` if the player was successfully killed, otherwise `False`.

- **`try_destroy_respawns(Player player)`**
  - Attempts to destroy all respawn positions for the specified player.
  - **Parameters:**
    - `player`: The player instance whose respawns will be removed.
  - **Returns:** `True` if the player's respawns were removed, otherwise `False`.

- **`setPos(Player player, Vec2 position)`**
  - Sets the position of the specified player.
  - **Parameters:**
    - `player`: The player instance.
    - `position`: The new position for the player.

- **`player_from_body(PlayerBody body)`**
  - Gets the player instance from a player's body.
  - **Parameters:**
    - `body`: The player's body.
  - **Returns:** The player instance or `null` if the body is `null`.

- **`id_from_player_body(PlayerBody body)`**
  - Gets the player ID from a player's body.
  - **Parameters:**
    - `body`: The player's body.
  - **Returns:** The player ID or 256 if the body is `null`.

- **`Physics_from_body(PlayerBody body)`**
  - Gets the physics instance from a player's body.
  - **Parameters:**
    - `body`: The player's body.
  - **Returns:** The player's physics instance or `null` if the body is `null`.

- **`clear_ropes(PlayerBody body)`**
  - Clears all ropes from the player's body.
  - **Parameters:**
    - `body`: The player's body.

- **`does_own_rope(PlayerBody body)`**
  - Checks if the player owns the rope attached to their body.
  - **Parameters:**
    - `body`: The player's body.
  - **Returns:** `True` if the player owns the rope, otherwise `False`.

#### `AGoodNameLib.match`

This class manages the match state.

- **`SuddenDeathState`**
  - Gets or sets the sudden death state of the game.
  - **Property:** `bool SuddenDeathState`

---

## Example Mod Using AGNL

```csharp
using BepInEx;
using BoplFixedMath;
using HarmonyLib;
using UnityEngine;
using static UnityEngine.ParticleSystem.PlaybackState;

namespace example_agln
{
    [BepInPlugin(PLUGIN_GUID, PLUGIN_NAME, PLUGIN_VERSION)]
    public class Plugin : BaseUnityPlugin
    {
        public const string PLUGIN_GUID = "com.your_name.example_agnl";
        public const string PLUGIN_NAME = "example_agnl";
        public const string PLUGIN_VERSION = "1.0.0";

        private void Awake()
        {
            // Plugin startup logic
            Logger.LogInfo($"Plugin {PLUGIN_GUID} is loaded!");

            var harmony = new Harmony(PLUGIN_GUID);
            harmony.PatchAll(typeof(Patches));
        }
    }

    public class Patches
    {
        //basic plugin which gives dash the ability to disconnect grapple hooks
        [HarmonyPatch(typeof(Dash), "performDash")]
        [HarmonyPostfix]
        public static void PatchDash(Dash __instance)
        {
            PlayerBody body = __instance.body;
            if (!AGoodNameLib.player.does_own_rope(body))
            {
                AGoodNameLib.player.clear_ropes(body);
            }
        }
    }
}
```