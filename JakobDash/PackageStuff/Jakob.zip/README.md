Reverts the nerf for Dash in the 2.2.4 hotfix;
3.2s - > 4.0s
Which made it impossible to stay in the air infinitely;

# this mod changes it back to 3.2s; become Jakob destroyer of fun